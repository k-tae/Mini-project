#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

void main(void)
{
	printf("Hello\n");
}
